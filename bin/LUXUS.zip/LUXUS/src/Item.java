
public interface Item
{
    public Location getLocation();
}
