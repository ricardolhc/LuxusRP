public interface Actor
{
    public void act();
}
